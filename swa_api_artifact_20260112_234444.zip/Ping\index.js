﻿module.exports = async function (context, req) {
  context.res = {
    status: 200,
    headers: { "content-type": "application/json" },
    body: { ok: true, name: "Ping", ts: new Date().toISOString() }
  };
};
